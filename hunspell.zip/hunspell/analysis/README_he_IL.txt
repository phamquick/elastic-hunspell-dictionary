This Hebrew dictionary in Myspell format was generated automatically from
data prepared by the Hspell project:

	http://ivrix.org.il/projects/spell-checker

Hspell version 1.0 was used.

This dictionary is Copyright (C) 2000-2006, Nadav Har'El and Dan Kenigsberg.
It is licensed under the GNU General Public License (GPL).
