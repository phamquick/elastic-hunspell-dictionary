
                          Den store danske ordliste

The Comprehensive Danish Dictionary (DSDO) is a free spell-checking dictionary
for Danish published by Sk�ne Sj�lland Linux User Group (SSLUG).  One thing
which makes this dictionary different from most other dictionaries is that it
basically is the result of a vote among the proof-readers.  The editorial
group has _not_ proof-read all the words in the dictionary, but guides the
proof-readers and keeps track of the overall status of the dictionary.

You can read more about the project at:

   http://da.speling.org/

Download the latest edition of this series from:

   http://da.speling.org/filer/

----------------------------------------------------------------------------

Hvis der er fejl i ordlisten kan du rapportere det p�:

                   http://da.speling.org/fejlmelding/

Eller per e-post til <sparre@speling.org>.

----------------------------------------------------------------------------

Se venligst installationsvejledningen p� Dansk OpenOffice.org-forum:

   http://www.oooforum.dk/viewtopic.php?t=249

