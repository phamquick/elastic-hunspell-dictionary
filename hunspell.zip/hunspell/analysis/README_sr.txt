Licenca:

Sve datoteke su izdate pod Gnuovom Slabijom opštom javnom licencom (GNU LGPL) kako je objavljuje Zadužbina za slobodni softver (FSF); bilo verzije 2.1 te Licence, bilo (po vašem nahođenju) koje novije verzije. 

Dozvoljena je upotreba ovog izdanja rečnika pod uslovima Moziline javne licence u verziji 1.1 ili novije (MPL) kao i pod uslovima Gnuove Opšte javne licence 
verzije u verziji 2 ili novije (GNU GPL).

Dozvoljena je upotreba ovog izdanja rečnika pod uslovima Kriejtiv komons Autorstvo-Deliti pod istim uslovima 3.0 Unported licencom (Creative Commons BY-SA Unported) kako je objavljuje organizacija Kriejtiv komons.

Provera pisanja je zasnovana na srpskom GNU aspel rečniku koji je priredio Goran Rakić (http://srpski.org/aspell) uz sve potrebne dozvole za reizdavanje i relicenciranje. Izdanje uključuje ispravke i dopune koje su priredili Ranko Tomić (ranko na cirilica tačka org) i Miloš Komarčević (kmilos na gmail tačka com).

Spisak se sastoji od 222045 reči i oblika.

