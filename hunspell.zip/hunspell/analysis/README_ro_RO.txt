The Romanian dictionary is taken from the rospell project:

--------------------------------------------------------------------------------

Packaging:
  Lucian Constantin (rospell) <struct_bylighting at yahoo dot com>

Original Word List By:
  Lucian Constantin (rospell) <struct_bylighting at yahoo dot com>
  Sorin Sbarnea (http://www.i18n.ro)
  Alexandru Szasz (Mozilla and OpenOffice.org Romanian Translation Team)
  Ionut Paduraru (http://www.archeus.ro)
  Adrian Stoica (OpenOffice.org Romanian Translation Team) <adrian dot stoica at cuvinte dot ro>
  Nicu Buculei (OpenOffice.org Romanian Translation Team) <nicu at apsro dot com>
  Catalin Francu (http://dexonline.ro)
  Ionel Mugurel Ciobica (previous aspell releases) <tgakic at sg10 chem tue nl>
  Mihai Budiu (ispell dictionary) <mihaib at cs cmu edu>

Copyright Terms:

 GPL 2.0/LGPL 2.1/MPL 1.1 tri-license

 The contents of this software may be used under the terms of
 the GNU General Public License Version 2 or later (see COPYING.GPL), or
 the GNU Lesser General Public License Version 2.1 or later (the "LGPL",
 see COPYING.LGPL) or (excepting the LGPLed GNU gettext library in the
 intl/ directory) the Mozilla Public License Version 1.1 or later
 (the "MPL", see COPYING.MPL).

 Software distributed under these licenses is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the licences
 for the specific language governing rights and limitations under the licenses.


Support:

  Please direct all your questions on http://groups.google.com/group/rospell mailing
  list, or contact the packager directly.
